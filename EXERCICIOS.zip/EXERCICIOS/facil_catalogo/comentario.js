const express = require('express');
const router = express.Router();

// Mock data (simulando um banco de dados)
let posts = [{ id: 1, titulo: "Primeiro Post", conteudo: "Conteúdo do primeiro post." }];

// Rota para CRIAR um novo post (Create)
router.post('/', (req, res) => {
    // Lógica para adicionar um novo post
    res.status(201).json({ message: "Post criado com sucesso!" });
});

// Rota para LER todos os posts (Read)
router.get('/', (req, res) => {
    res.json(posts);
});

// Rota para LER um post específico (Read)
router.get('/:id', (req, res) => {
    const post = posts.find(p => p.id === parseInt(req.params.id));
    if (!post) return res.status(404).send('Post não encontrado.');
    res.json(post);
});

// Rota para ATUALIZAR um post (Update)
router.put('/:id', (req, res) => {
    // Lógica para atualizar o post
    res.json({ message: `Post ${req.params.id} atualizado com sucesso!` });
});

// Rota para DELETAR um post (Delete)
router.delete('/:id', (req, res) => {
    // Lógica para deletar o post
    res.json({ message: `Post ${req.params.id} deletado com sucesso!` });
});

module.exports = router;