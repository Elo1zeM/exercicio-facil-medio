const express = require('express');
const app = express();
const PORT = 3008;

// Middleware para interpretar o corpo das requisições como JSON
app.use(express.json());

// Array para simular um banco de dados em memória
let filmes = [
    { id: 1, titulo: 'Jogos Vorazes', genero: 'Ação' , ano_lancamento: '2012', status: 'Para assistir'},
    { id: 2, titulo: 'Homem-Aranha', genero: 'Ficção científica' , ano_lancamento: '2002', status: 'Assistido'},
];

let proximoId = 3;

// ROTA GET: Listar todos os produtos
app.get('/filmes', (req, res) => {
    res.json(filmes);
});

// ROTA GET: Buscar filmes por ID
app.get('/filmes/:id', (req, res) => {
    const id = parseInt(req.params.id);
    const filmes = filmes.find(p => p.id === id);
    
    if (filmes) {
        res.json(filmes);
    } else {
        res.status(404).json({ erro: 'Filme não encontrado!' });
    }
});

// ROTA POST: Criar um novo produto
app.post('/filmes', (req, res) => {
    const { titulo, genero, ano_lancamento, status } = req.body;
    
    // Validação básica para garantir que todos os campos foram enviados
    if (!titulo || !genero || !ano_lancamento || !status) {
        return res.status(400).json({ erro: 'Título, status, gênero e ano de lançamento são obrigatórios' });
    }
    
    // Cria o novo objeto de produto com um ID automático
    const novoFilmes = {
        id: proximoId,
        titulo: titulo,
        genero: genero,
        ano_lancamento: ano_lancamento,
        status: status
    };
    
   
    proximoId++;
    
    filmes.push(novoFilmes);
    
    // Retorna o produto recém-criado com o status 201 (Created)
    res.status(201).json(novoFilmes);
});

// ROTA PUT: Atualizar um produto existente
app.put('/filmes/:id', (req, res) => {
    const id = parseInt(req.params.id);
    const index = filmes.findIndex(p => p.id === id);
    
    if (index === -1) {
        return res.status(404).json({ erro: 'Filme não encontrado' });
    }
    
    // Atualiza o objeto do produto no array
    // Mantém o ID original e atualiza os outros campos com os dados da requisição
    filmes[index] = { ...filmes[index], ...req.body };
    
    res.json(filmes[index]);
});

// ROTA DELETE: 
app.delete('/filmes/:id', (req, res) => {
    const id = parseInt(req.params.id);
    const index = filmes.findIndex(p => p.id === id);
    
    if (index === -1) {
        return res.status(404).json({ erro: 'Filme não encontrado' });
    }
    
    // Remove o produto do array usando o índice encontrado
    filmes.splice(index, 1);
    
    // Retorna o status 204 (No Content) para indicar sucesso na remoção
    res.status(204).send();
});

app.listen(PORT, () => {
    console.log(`API rodando em http://localhost:${PORT}`);
});